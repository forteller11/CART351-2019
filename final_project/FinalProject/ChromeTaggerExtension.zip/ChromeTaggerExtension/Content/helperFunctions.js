'use strict';

function rgbaCol(r, g, b, a) {
  return "rgba(" + r + "," + g + "," + b + "," + a + ")";
}

function constrain(x, min, max) {
  if (x < min) x = min;
  if (x > max) x = max;
  return x;
}
