<?php

require('../vendor/autoload.php');

$app = new Silex\Application();
$app['debug'] = true;

// Register the monolog logging service
$app->register(new Silex\Provider\MonologServiceProvider(), array(
  'monolog.logfile' => 'php://stderr',
));

// Register view rendering
$app->register(new Silex\Provider\TwigServiceProvider(), array(
    'twig.path' => __DIR__.'/views',
));

// Our web handlers

$app->get('/', function() use($app) {
  $app['monolog']->addDebug('logging output.');
  return $app['twig']->render('index.twig');
});

$app->post('/', function() use($app) {
  $app['monolog']->addDebug('logging output.');
  return $app['twig']->render('index.twig');
});


header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: *");

$db = pg_connect(getenv("DATABASE_URL"));
if (!$db){
  echo "Error: data base not opened!";
  exit;
}

//check if there has been something posted to the server to be processed
if($_SERVER['REQUEST_METHOD'] == 'GET')
{
  if ($_GET['hostname'] != NULL){
     $query = "SELECT strokeData FROM strokes WHERE url ='" . $_GET['hostname']."'";
     $queryResult = pg_query($db, $query);
     $queryResultArr = pg_fetch_all($queryResult);
    foreach($queryResultArr as $col){
      foreach($col as $row){
        echo $row;
      }
    }

  } else
      echo "ERROR: specify a 'hostname' in the url!!";
}

if($_SERVER['REQUEST_METHOD'] == 'POST')
{

  echo "||POST REQUEST:  ";
  echo $_SERVER['REQUEST_URI'];

$entityBody = file_get_contents('php://input');

$entityBody = file_get_contents('php://input');
  echo " POST BODY: ";

$urlAndStrokeDataArr = explode("|_|", $entityBody);
echo "||urlE: ". $urlAndStrokeDataArr[0];
echo "||strokeDataE: " . $urlAndStrokeDataArr[1];

$timeAtPost = date('Y/m/d/H/i/s', time());

$insertStatement = "INSERT INTO strokes (url, creationDate, strokeData) VALUES ('". $urlAndStrokeDataArr[0]. "','" . $timeAtPost ."','".$urlAndStrokeDataArr[1]."')";
echo "INSERT STATEMENT: ".$insertStatement;
pg_query($db, $insertStatement);
  echo " :END OF POST REQUEST|| ";

}

pg_close($db);
$app->run();
